package Mar17Lab8.Task9;
public class CSE111Student extends Student {
    String msg="I love Java Programming";
    public CSE111Student(){
       
    }
    @Override
    public String shout(){
    return msg;
  }

}
