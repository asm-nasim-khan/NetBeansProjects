package Mar17Lab8.Task9;
public class CSEStudent extends Student {
    String msg="I want to transfer to CSE";
   public CSEStudent(){
        
    }
   @Override
   public String shout(){
    return msg;
  }
    

}
