package Feb25Lab5.Task10;
public class Student {
    public String name;
    public  int id;
    public static int count = 0;
    public Student(String n,int no){
        name = n;
        id = no;
    }

}
