package Feb25Lab5.Task8;
public class Course {
    public String co;
    public Course(String s){
        co = s;
    }

}
