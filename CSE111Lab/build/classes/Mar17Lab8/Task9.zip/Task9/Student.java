package Mar17Lab8.Task9;    
public class Student{
  public String msg = "I love BU";
  public String shout(){
    return msg;
  }
}

